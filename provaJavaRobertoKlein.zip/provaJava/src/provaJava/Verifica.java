//Roberto Luiz Klein Filho
package provaJava;

public interface Verifica {

	void validar();
	
}
